if (document.location.href.like('*youtube-view?url=*')) {
   
}
