  SOCIALBROWSER.log(' >>> Alexa script activated ...');
  SOCIALBROWSER.var.blocking.social.allow_alexa = true;

