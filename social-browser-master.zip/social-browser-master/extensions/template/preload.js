
  SOCIALBROWSER.log('extension template say hi in browser console')

