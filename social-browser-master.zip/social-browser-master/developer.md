Request Data Life Cycle

Javascript Run or send to ( IPC or Parent WS )
IPC Run or send to ( Parent WS or Javascript )
Parent WS run or send to Child WS
Child Ws Run or send to ( Javascript or Parent WS)

npm install "https://github.com/castlabs/electron-releases#v34.2.0+wvcus" --save-dev


 python -m pip install --upgrade castlabs-evs

python -m castlabs_evs.vmp sign-pkg ..
